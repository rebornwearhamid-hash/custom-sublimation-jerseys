/**
 * Custom Sublimation Jerseys — builder.js
 * Interactive Jersey Builder Module
 */

const JerseyBuilder = (function () {

  /* ============================================================
     STATE
     ============================================================ */
  const state = {
    sport:       'basketball',
    primary:     '#1a3a8c',
    secondary:   '#00e5ff',
    accent:      '#ffffff',
    playerName:  'YOUR NAME',
    number:      '23',
    logoFile:    null,
    logoDataUrl: null,
  };

  /* ============================================================
     JERSEY SVG TEMPLATES
     ============================================================ */
  const templates = {
    basketball: (s) => `
      <svg viewBox="0 0 200 230" xmlns="http://www.w3.org/2000/svg" id="jersey-svg">
        <!-- Body -->
        <path d="M52 22 L14 58 L38 74 L38 205 L162 205 L162 74 L186 58 L148 22 L126 36 Q100 48 74 36 Z"
              fill="${s.primary}" stroke="${s.secondary}" stroke-width="1.5"/>
        <!-- Collar -->
        <path d="M74 36 Q100 52 126 36 L118 52 Q100 62 82 52 Z" fill="${s.secondary}" opacity="0.3"/>
        <!-- Side stripes -->
        <rect x="38"  y="74" width="16" height="131" fill="${s.secondary}" opacity="0.18"/>
        <rect x="146" y="74" width="16" height="131" fill="${s.secondary}" opacity="0.18"/>
        <!-- Number -->
        <text x="100" y="142" text-anchor="middle" fill="${s.accent}"
              font-size="52" font-weight="900" font-family="Barlow Condensed, sans-serif"
              letter-spacing="-2">${s.number}</text>
        <!-- Name -->
        <text x="100" y="177" text-anchor="middle" fill="${s.accent}"
              font-size="14" font-family="Barlow, sans-serif"
              letter-spacing="3" opacity="0.85">${s.playerName.toUpperCase()}</text>
        <!-- Armhole detail -->
        <path d="M38 74 Q26 66 14 58" fill="none" stroke="${s.secondary}" stroke-width="1" opacity="0.5"/>
        <path d="M162 74 Q174 66 186 58" fill="none" stroke="${s.secondary}" stroke-width="1" opacity="0.5"/>
      </svg>`,

    football: (s) => `
      <svg viewBox="0 0 200 230" xmlns="http://www.w3.org/2000/svg" id="jersey-svg">
        <path d="M52 22 L14 58 L38 74 L38 205 L162 205 L162 74 L186 58 L148 22 L126 36 Q100 48 74 36 Z"
              fill="${s.primary}" stroke="${s.secondary}" stroke-width="1.5"/>
        <!-- Shoulder panels -->
        <path d="M52 22 L74 36 L82 55 L50 74 L38 74 L14 58 Z" fill="${s.secondary}" opacity="0.25"/>
        <path d="M148 22 L126 36 L118 55 L150 74 L162 74 L186 58 Z" fill="${s.secondary}" opacity="0.25"/>
        <!-- Horizontal stripes -->
        <rect x="38" y="88" width="124" height="14" fill="${s.secondary}" opacity="0.2"/>
        <rect x="38" y="106" width="124" height="6"  fill="${s.accent}"   opacity="0.12"/>
        <!-- Number -->
        <text x="100" y="155" text-anchor="middle" fill="${s.accent}"
              font-size="52" font-weight="900" font-family="Barlow Condensed, sans-serif"
              letter-spacing="-2">${s.number}</text>
        <!-- Name -->
        <text x="100" y="185" text-anchor="middle" fill="${s.accent}"
              font-size="13" font-family="Barlow, sans-serif"
              letter-spacing="3" opacity="0.85">${s.playerName.toUpperCase()}</text>
      </svg>`,

    soccer: (s) => `
      <svg viewBox="0 0 200 230" xmlns="http://www.w3.org/2000/svg" id="jersey-svg">
        <path d="M52 22 L14 58 L38 74 L38 205 L162 205 L162 74 L186 58 L148 22 L126 36 Q100 46 74 36 Z"
              fill="${s.primary}" stroke="${s.secondary}" stroke-width="1.5"/>
        <!-- V-neck collar -->
        <path d="M86 36 L100 60 L114 36 L108 32 L100 48 L92 32 Z" fill="${s.secondary}" opacity="0.4"/>
        <!-- Side panels -->
        <path d="M38 74 L38 205 L58 205 L58 74 Z" fill="${s.secondary}" opacity="0.2"/>
        <path d="M162 74 L162 205 L142 205 L142 74 Z" fill="${s.secondary}" opacity="0.2"/>
        <!-- Number -->
        <text x="100" y="150" text-anchor="middle" fill="${s.accent}"
              font-size="58" font-weight="900" font-family="Barlow Condensed, sans-serif"
              letter-spacing="-2">${s.number}</text>
        <!-- Name -->
        <text x="100" y="180" text-anchor="middle" fill="${s.accent}"
              font-size="13" font-family="Barlow, sans-serif"
              letter-spacing="3" opacity="0.85">${s.playerName.toUpperCase()}</text>
      </svg>`,

    baseball: (s) => `
      <svg viewBox="0 0 200 230" xmlns="http://www.w3.org/2000/svg" id="jersey-svg">
        <path d="M52 22 L14 58 L38 74 L38 205 L162 205 L162 74 L186 58 L148 22 L126 36 Q100 48 74 36 Z"
              fill="${s.primary}" stroke="${s.secondary}" stroke-width="1.5"/>
        <!-- Button placket -->
        <rect x="96" y="36" width="8" height="169" fill="${s.secondary}" opacity="0.2"/>
        <!-- Buttons -->
        <circle cx="100" cy="50"  r="2.5" fill="${s.secondary}" opacity="0.6"/>
        <circle cx="100" cy="68"  r="2.5" fill="${s.secondary}" opacity="0.6"/>
        <circle cx="100" cy="86"  r="2.5" fill="${s.secondary}" opacity="0.6"/>
        <circle cx="100" cy="104" r="2.5" fill="${s.secondary}" opacity="0.6"/>
        <!-- Pinstripes -->
        <line x1="62" y1="74" x2="62" y2="205" stroke="${s.secondary}" stroke-width="1" opacity="0.15"/>
        <line x1="72" y1="74" x2="72" y2="205" stroke="${s.secondary}" stroke-width="1" opacity="0.15"/>
        <line x1="128" y1="74" x2="128" y2="205" stroke="${s.secondary}" stroke-width="1" opacity="0.15"/>
        <line x1="138" y1="74" x2="138" y2="205" stroke="${s.secondary}" stroke-width="1" opacity="0.15"/>
        <!-- Number -->
        <text x="100" y="155" text-anchor="middle" fill="${s.accent}"
              font-size="50" font-weight="900" font-family="Barlow Condensed, sans-serif">${s.number}</text>
        <!-- Name -->
        <text x="100" y="183" text-anchor="middle" fill="${s.accent}"
              font-size="13" font-family="Barlow, sans-serif"
              letter-spacing="3" opacity="0.85">${s.playerName.toUpperCase()}</text>
      </svg>`,
  };

  /* ============================================================
     RENDER
     ============================================================ */
  function render() {
    const container = document.getElementById('jersey-preview');
    if (!container) return;

    const tmpl = templates[state.sport];
    if (!tmpl) return;

    container.innerHTML = tmpl(state);

    // Overlay logo if uploaded
    if (state.logoDataUrl) {
      const svg = container.querySelector('svg');
      const img = document.createElementNS('http://www.w3.org/2000/svg', 'image');
      img.setAttribute('href', state.logoDataUrl);
      img.setAttribute('x', '75');
      img.setAttribute('y', '60');
      img.setAttribute('width', '50');
      img.setAttribute('height', '50');
      img.setAttribute('preserveAspectRatio', 'xMidYMid meet');
      svg.appendChild(img);
    }
  }

  /* ============================================================
     BIND CONTROLS
     ============================================================ */
  function bindControls() {

    // Sport selector tabs
    document.querySelectorAll('[data-sport]').forEach(btn => {
      btn.addEventListener('click', () => {
        state.sport = btn.dataset.sport;
        document.querySelectorAll('[data-sport]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        render();
      });
    });

    // Color pickers
    function bindColor(inputId, stateKey) {
      const input = document.getElementById(inputId);
      if (!input) return;
      input.value = state[stateKey];
      input.addEventListener('input', () => {
        state[stateKey] = input.value;
        // Sync swatch if present
        const swatch = document.querySelector(`[data-color-target="${inputId}"]`);
        if (swatch) swatch.style.background = input.value;
        render();
      });
    }
    bindColor('color-primary',   'primary');
    bindColor('color-secondary', 'secondary');
    bindColor('color-accent',    'accent');

    // Color swatches (preset colors)
    document.querySelectorAll('.color-swatch').forEach(swatch => {
      swatch.addEventListener('click', () => {
        const target  = swatch.dataset.target;
        const color   = swatch.dataset.color;
        const input   = document.getElementById(target);
        if (input) {
          input.value = color;
          input.dispatchEvent(new Event('input'));
        }
        // Active state within group
        const group = swatch.closest('.swatch-group');
        if (group) {
          group.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
          swatch.classList.add('active');
        }
        render();
      });
    });

    // Player name
    const nameInput = document.getElementById('player-name');
    if (nameInput) {
      nameInput.value = state.playerName === 'YOUR NAME' ? '' : state.playerName;
      nameInput.addEventListener('input', () => {
        state.playerName = nameInput.value.trim() || 'YOUR NAME';
        render();
      });
    }

    // Player number
    const numInput = document.getElementById('player-number');
    if (numInput) {
      numInput.value = state.number;
      numInput.addEventListener('input', () => {
        const val = numInput.value.replace(/\D/g, '').slice(0, 2);
        numInput.value = val;
        state.number = val || '0';
        render();
      });
    }

    // Logo upload
    const logoInput = document.getElementById('logo-upload');
    if (logoInput) {
      logoInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const validTypes = ['image/png', 'image/jpeg', 'image/svg+xml', 'image/gif'];
        if (!validTypes.includes(file.type)) {
          alert('Please upload a PNG, JPG, or SVG image.');
          return;
        }

        const reader = new FileReader();
        reader.onload = (ev) => {
          state.logoFile    = file;
          state.logoDataUrl = ev.target.result;
          render();
          // Show remove button
          const removeBtn = document.getElementById('logo-remove');
          if (removeBtn) removeBtn.style.display = 'inline-flex';
          // Show preview
          const logoPreview = document.getElementById('logo-preview');
          if (logoPreview) {
            logoPreview.src   = ev.target.result;
            logoPreview.style.display = 'block';
          }
        };
        reader.readAsDataURL(file);
      });
    }

    // Logo remove
    const removeBtn = document.getElementById('logo-remove');
    if (removeBtn) {
      removeBtn.addEventListener('click', () => {
        state.logoFile    = null;
        state.logoDataUrl = null;
        const logoInput = document.getElementById('logo-upload');
        if (logoInput) logoInput.value = '';
        const logoPreview = document.getElementById('logo-preview');
        if (logoPreview) { logoPreview.src = ''; logoPreview.style.display = 'none'; }
        removeBtn.style.display = 'none';
        render();
      });
    }

    // Request quote button (builder)
    const quoteBtn = document.getElementById('builder-quote-btn');
    if (quoteBtn) {
      quoteBtn.addEventListener('click', () => {
        const summary = `
Sport: ${state.sport.charAt(0).toUpperCase() + state.sport.slice(1)}
Player Name: ${state.playerName}
Number: ${state.number}
Primary Color: ${state.primary}
Secondary Color: ${state.secondary}
        `.trim();

        const quoteText = document.getElementById('quote-summary-text');
        if (quoteText) quoteText.value = summary;

        const quoteSection = document.getElementById('builder-quote-form');
        if (quoteSection) {
          quoteSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    }
  }

  /* ============================================================
     PUBLIC INIT
     ============================================================ */
  function init() {
    render();
    bindControls();

    // Activate first sport button
    const firstSportBtn = document.querySelector('[data-sport="basketball"]');
    if (firstSportBtn) firstSportBtn.classList.add('active');
  }

  return { init };

})();

// Auto-init when DOM ready
document.addEventListener('DOMContentLoaded', () => JerseyBuilder.init());
